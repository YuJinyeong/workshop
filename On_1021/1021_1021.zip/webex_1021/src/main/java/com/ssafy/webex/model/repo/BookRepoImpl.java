package com.ssafy.webex.model.repo;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ssafy.webex.model.dto.Book;

@Repository // 나중에 component scan으로 찾아서 빈으로 등록 예정
public class BookRepoImpl implements BookRepository {

	private static final Logger logger = LoggerFactory.getLogger(BookRepoImpl.class);

	@Override
	public int insert(Book book) {
		logger.debug("book: {}", book);
		return 0;
	}

	@Override
	public int update(Book book) {
		logger.debug("book: {}", book);
		return 0;
	}

	@Override
	public int delete(String isbn) {
		logger.debug("isbn: {}", isbn);
		return 0;
	}

	@Override
	public Book select(String isbn) {
		logger.debug("isbn: {}", isbn);
		return null;
	}

	@Override
	public List<Book> selectAll() {
		logger.debug("select all");
		return null;
	}
}
