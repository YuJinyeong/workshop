package com.ssafy.webex.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

// 이건 환경 설정 파일이에요..
@Configuration
// 여기 가서 빈좀 찾아봐주세요..
@ComponentScan("com.ssafy.webex.model")
public class ApplicationConfig {

}
