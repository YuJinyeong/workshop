package com.ssafy.webex.model.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.webex.model.dto.Book;
import com.ssafy.webex.model.repo.BookRepoImpl;
import com.ssafy.webex.model.repo.BookRepository;

@Service
public class BookServiceImpl implements BookService {

	private static final Logger logger = LoggerFactory.getLogger(BookServiceImpl.class);

	@Autowired
	private BookRepository bookRepo;
	
	@Override
	public int insert(Book book) {
		logger.debug("book: {}", book);
		return 0;
	}

	@Override
	public int update(Book book) {
		logger.debug("book: {}", book);
		return 0;
	}

	@Override
	public int delete(String isbn) {
		logger.debug("isbn: {}", isbn);
		return 0;
	}

	@Override
	public Book select(String isbn) {
		logger.debug("isbn: {}", isbn);
		return null;
	}

	@Override
	public List<Book> selectAll() {
		logger.debug("selectAll");
		return null;
	}

}
