package com.ssafy.webex.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ssafy.webex.config.ApplicationConfig;
import com.ssafy.webex.model.service.BookService;

public class Client {
	public static void main(String[] args) {
		// 스프링에게 메타 정보 파일을 넘겨준다.
		ApplicationContext ctx = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		// 스프링에게 빈을 달라고 한다.
		System.out.println(ctx.getBean(BookService.class));
	}
}
