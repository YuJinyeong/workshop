package com.ssafy.webex.model.service;

import java.util.List;

import com.ssafy.webex.model.dto.UserInfo;

public interface UserService {
	int insert(UserInfo info);

	int update(UserInfo info);

	int delete(String userId);

	UserInfo select(String userId);

	List<UserInfo> selectAll();
}
