package com.ssafy.webex.model.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.ssafy.webex.model.dto.UserInfo;
import com.ssafy.webex.model.repo.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	private UserRepository userRepo;

	@Override
	public int insert(UserInfo info) {
		logger.debug("userinfo: {}", info);
		return 0;
	}

	@Override
	public int update(UserInfo info) {
		logger.debug("userinfo: {}", info);
		return 0;
	}

	@Override
	public int delete(String userId) {
		logger.debug("userId: {}", userId);
		return 0;
	}

	@Override
	public UserInfo select(String userId) {
		logger.debug("userId: {}", userId);
		// 원래의 목적은 TX 처리
		return userRepo.select(userId);
	}

	@Override
	public List<UserInfo> selectAll() {
		logger.debug("selectAll:");
		return null;
	}

}
