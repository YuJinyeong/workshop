package com.ssafy.webex.model.repo;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ssafy.webex.model.dto.UserInfo;

@Repository
public class UserRepoImpl implements UserRepository {

	private static final Logger logger = LoggerFactory.getLogger(UserRepoImpl.class);

	@Override
	public int insert(UserInfo info) {
		logger.debug("userinfo: {}", info);
		return 0;
	}

	@Override
	public int update(UserInfo info) {
		logger.debug("userinfo: {}", info);
		return 0;
	}

	@Override
	public int delete(String userId) {
		logger.debug("userId: {}", userId);
		return 0;
	}

	@Override
	public UserInfo select(String userId) {
		logger.debug("userId: {}", userId);
		// 원래는  DB에서 조회해야 겠죠??
		if (userId.equals("ssafy")) {
			return new UserInfo(userId, "싸피맨", "1234");
		} else {
			return null;
		}
	}

	@Override
	public List<UserInfo> selectAll() {
		logger.debug("selectAll:");
		return null;
	}

}
