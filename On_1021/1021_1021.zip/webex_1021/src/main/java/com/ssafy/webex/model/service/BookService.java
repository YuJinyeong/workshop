package com.ssafy.webex.model.service;

import java.util.List;

import com.ssafy.webex.model.dto.Book;

public interface BookService {
	int insert(Book book);

	int update(Book book);

	int delete(String isbn);

	Book select(String isbn);

	List<Book> selectAll();
}
