package com.ssafy.webex.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssafy.webex.model.dto.Book;
import com.ssafy.webex.model.service.BookService;

@Controller
@RequestMapping("/book")
public class BookController {

	@Autowired
	private BookService service;

	private static final Logger logger = LoggerFactory.getLogger(BookController.class);

	// 도서 등록 화면 요청
	@GetMapping("/regist")
	public String bookRegForm(HttpServletResponse res) {
		Cookie cookie = new Cookie("cookie", "다이제스티브");
		cookie.setMaxAge(10 * 60);		
		cookie.setPath("/");
		res.addCookie(cookie);
		return "regist";
	}

	// 도서 등록 처리
	@PostMapping("/regist")
	public String bookReg(@ModelAttribute Book book, @CookieValue String cookie) {
		// @ModelAttribute: 화면에서 넘어온 파라미터들을 이용해서 DTO 생성 후 바로 받을 수 있다!!
		// 클래스 첫글자를 소문자로 해서 바로 Model에 담아주기까지..
		// model.addAttribute("book", book);
		logger.debug("book: {}", book);
		logger.debug("쿠키 확인: {}", cookie);
		// 모델 연결..
		service.insert(book);
		return "result";
	}

}
