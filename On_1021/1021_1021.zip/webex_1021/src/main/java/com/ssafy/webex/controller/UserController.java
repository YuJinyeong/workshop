package com.ssafy.webex.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.webex.model.dto.UserInfo;
import com.ssafy.webex.model.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserService service;
	
	@GetMapping("/login")
	public String loginForm() {
		// controller 단에서 예외 발생
		logger.debug("get, login form 요청");
		return "login";
	}

	@PostMapping("/login")
	public String doLogin(@RequestParam String id, @RequestParam String password, 
			@RequestParam(required = false) List<String> hobby,
			@RequestParam int age,
			HttpSession session) {
		logger.debug("post login 처리 {}", id + ":" + password + " : " + age+" : "+hobby);
		// 컨트롤러의 역할: 
		// 1. 파라미터 처리
		// 2. model 연동
		UserInfo info = service.select(id);
		session.setAttribute("loginUser", info);
		// 3. 화면 전환
		return "main";
	}
	
	@ExceptionHandler// Controller에서 발생하는  예외를 모아준다.
	public String handleError(Exception e) {
		e.printStackTrace();
		return "500";
	}
}
