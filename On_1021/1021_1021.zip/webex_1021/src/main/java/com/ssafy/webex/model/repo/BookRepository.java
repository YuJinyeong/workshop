package com.ssafy.webex.model.repo;

import java.util.List;

import com.ssafy.webex.model.dto.Book;

public interface BookRepository {
	int insert(Book book);

	int update(Book book);

	int delete(String isbn);

	Book select(String isbn);

	List<Book> selectAll();
}
