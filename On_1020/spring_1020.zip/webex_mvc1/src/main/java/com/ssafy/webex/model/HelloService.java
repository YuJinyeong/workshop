package com.ssafy.webex.model;

import org.springframework.stereotype.Service;

@Service
public class HelloService {

}
