package com.ssafy.webex.phone;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PhoneClient3 {

	public static void main(String[] args) {
		
		ApplicationContext ctx = new AnnotationConfigApplicationContext(ApplicationConfig.class);

		// 빈 요청
		AndroidPhone phone = ctx.getBean(SPhone.class);
		phone.call();

		PhoneUser puser = ctx.getBean(PhoneUser.class);
		puser.usePhone();
		System.out.println("phone: " + phone);

	}

}
