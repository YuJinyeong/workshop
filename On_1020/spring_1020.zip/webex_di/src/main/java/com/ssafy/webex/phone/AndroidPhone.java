package com.ssafy.webex.phone;

public interface AndroidPhone {
	void call();
}
