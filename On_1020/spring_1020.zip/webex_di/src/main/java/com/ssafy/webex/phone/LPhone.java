package com.ssafy.webex.phone;

import org.springframework.stereotype.Component;

@Component
public class LPhone implements AndroidPhone{

	@Override
	public void call() {
		System.out.println("이것은 LPhone이다.");
	}
}
