package com.ssafy.webex.phone;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

// 자바 기반의 설정 파일 만들기.

@Configuration// 이것은 설정 파일이에요..
@ComponentScan("com.ssafy.webex.phone")
public class ApplicationConfig {

	/*
	 * @Bean public SPhone sPhone() { return new SPhone(); }
	 * 
	 * @Bean public LPhone lPhone() { return new LPhone(); }
	 * 
	 * @Bean public PhoneUser phoneUser() { PhoneUser user = new PhoneUser();
	 * user.setPhone(lPhone()); return user; }
	 */
}
