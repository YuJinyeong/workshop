package com.ssafy.webex.phone;

import org.springframework.stereotype.Component;

@Component("sPhone")
public class SPhone implements AndroidPhone{
	
	public SPhone() {
		System.out.println("여기는 Sphone 기본 생성자/");
	}

	@Override
	public void call() {
		System.out.println("이것은 S폰이다.");
	}

}
