package com.ssafy.webex.phone;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PhoneClinet {

	public static void main(String[] args) {
		// ApplicatinContext - SpringFramework
		// 조립 설명서 바탕으로 조립해주세요~~
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/ssafy/webex/phone/myconfig.xml");
		
		// 빈 요청
		AndroidPhone phone = ctx.getBean(SPhone.class);
		phone.call();
		
		PhoneUser puser = ctx.getBean(PhoneUser.class);
		puser.usePhone();
		System.out.println("phone: "+phone);
	}

}
