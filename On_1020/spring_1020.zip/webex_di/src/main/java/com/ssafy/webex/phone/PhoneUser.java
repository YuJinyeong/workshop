package com.ssafy.webex.phone;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


@Component
public class PhoneUser {
	// has a 관계 - 멤버 변수 --> 설정 방법은? 두가지
	private AndroidPhone phone;

	public PhoneUser() {
	}

	// Exception in thread "main"
	// org.springframework.beans.factory.UnsatisfiedDependencyException:
	// Error creating bean with name 'phoneUser' defined in file
	// [C:\SSAFY\WS_STS\webex_di\target\classes\com\ssafy\webex\phone\PhoneUser.class]:
	// Unsatisfied dependency expressed through constructor parameter 0;
	// nested exception is
	// org.springframework.beans.factory.NoUniqueBeanDefinitionException:
	// No qualifying bean of type 'com.ssafy.webex.phone.AndroidPhone' available:
	// expected single matching bean but found 2: LPhone,SPhone

	// 생성자를 통한 빈 주입
	@Autowired // 타입 기반으로 빈을 자동 주입해준다.!!
	// 이름 기반으로 빈을 한정시켜준다. 이때 이름은 클래스 첫글자를 소문자로
	public PhoneUser(@Qualifier("sPhone") AndroidPhone phone) {
		this.phone = phone;
	}

	// setter를 통한 주입
	@Autowired // 타입 기반으로 빈을 자동 주입해준다.!!
	@Qualifier("sPhone") // 이름 기반으로 빈을 한정시켜준다. 이때 이름은 클래스 첫글자를 소문자로
	public void setPhone(AndroidPhone phone) {
		this.phone = phone;
	}

	public void usePhone() {
		System.out.println(phone + " 사용중");
		phone.call();
	}
}
