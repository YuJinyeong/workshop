package com.ssafy.web.service;

import com.ssafy.web.model.HelloDto;

public interface HelloService {

	HelloDto greeting();
}
