package com.ssafy.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.web.dao.HelloDao;
import com.ssafy.web.model.HelloDto;

@Service
public class HelloServiceImpl implements HelloService {

	@Autowired
	private HelloDao helloDao;
	
	@Override
	public HelloDto greeting() {
		HelloDto helloDto = new HelloDto();
		helloDto.setMessage(helloDao.greeting());
		return helloDto;
	}

}
