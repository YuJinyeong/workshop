package com.ssafy.web.dao;

public interface HelloDao {

	String greeting();
	
}
