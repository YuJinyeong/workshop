package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.dto.User;
import com.example.demo.model.repo.UserRepo;

@SpringBootTest
public class RepoTest {
	@Autowired
	UserRepo repo;
	
	@Test
	public void selectTest(){
		User user = repo.select("ssafy");
		assertEquals(user.getName(), "김싸피");
	}
	
	@Test
	public void selectAllTest(){
		List<User> users = repo.selectAll();
		assertEquals(users.size(), 1);
	}
	
	@Test
	@Transactional //일시적으로 테스트만.. 나중에 원래대로 해놓고 가~~
	public void insertTest(){
		User user = new User("hong", "홍길동", "1234");
		int result = repo.insert(user);
		
		assertEquals(1, result);
		
		User selected = repo.select("hong");
		assertEquals(selected.getName(), "홍길동");
	}
	
	@Test
	@Transactional
	public void deleteTest(){
		int result = repo.delete("ssafy");
		
		assertEquals(1, result);
		
	}
	
	@Test
	@Transactional
	public void updateTest(){
		User selected = repo.select("ssafy");
		selected.setName("홍싸피");
		int result = repo.update(selected);
		
		assertEquals(1, result);
		
		selected = repo.select("ssafy");
		assertEquals(selected.getName(), "홍싸피");
	}
}
