package com.example.demo.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//DTO --> Java Beans
@Data//getter, setter, toString, hashCode 추가
@NoArgsConstructor //기본 생성자 추가
@AllArgsConstructor //생성자
public class User {
	private String id;
	private String name;
	private String pass;
}
