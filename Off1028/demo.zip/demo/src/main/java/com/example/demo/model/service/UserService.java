package com.example.demo.model.service;

import java.util.List;

import com.example.demo.model.dto.User;

public interface UserService {
	User insert(User user);
	User update(User user);
	int delete(String id);
	User select(String id);
	List<User> selectAll();
}
