package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.dto.User;
import com.example.demo.model.service.UserService;

@RestController //rest 전용 --> @ResponseBody
@RequestMapping("/user")
@CrossOrigin("*")
public class UserRestController {
	
	@Autowired
	UserService service;
	
	@GetMapping("/{id}") //user/hong
	public User getUser(@PathVariable String id) {
		return service.select(id);
	}
	
	@GetMapping
	public List<User> getAllUser() {
		return service.selectAll();
	}
	
	@PostMapping // /user/
	public User insert(@RequestBody/*json 형태로 보내지만 알아서 맞춰주쇼*/ User user) {
		return service.insert(user);
	}
	
	@DeleteMapping("/{id}") // /user
	public int delete(@PathVariable String id) {
		return service.delete(id);
	}
	
	@PutMapping
	public User update(@RequestBody User user) {
		return service.update(user);
	}
	
}
