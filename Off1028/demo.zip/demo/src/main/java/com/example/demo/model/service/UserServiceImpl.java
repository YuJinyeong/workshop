package com.example.demo.model.service;

import java.util.List;

import org.apache.commons.logging.LogFactory;
import org.mybatis.logging.Logger;
import org.mybatis.logging.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.dto.User;
import com.example.demo.model.repo.UserRepo;

@Service
public class UserServiceImpl implements UserService {
		
	@Autowired
	UserRepo repo;
	
	@Override
	@Transactional
	public User insert(User user) {
		int result = repo.insert(user);
		if(result == 1) return repo.select(user.getId());
		else return null;
	}

	@Override
	public User update(User user) {
		int result = repo.update(user);
		if(result == 1) return repo.select(user.getId());
		else return null;
	}

	@Override
	public int delete(String id) {
		return repo.delete(id);
	}

	@Override
	public User select(String id) {
		return repo.select(id);
	}

	@Override
	public List<User> selectAll() {
		return repo.selectAll();
	}

}
