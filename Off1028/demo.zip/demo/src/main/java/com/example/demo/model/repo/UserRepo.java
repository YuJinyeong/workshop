package com.example.demo.model.repo;

import java.util.List;

import com.example.demo.model.dto.User;

public interface UserRepo {
	int insert(User user);
	int update(User user);
	int delete(String id);
	User select(String id);
	List<User> selectAll();
}
