export default {
  template: `
    <p>
      <a href="./index.html">HOME</a>
      <a href="./list.html">게시판</a>
    </p>`,
};
