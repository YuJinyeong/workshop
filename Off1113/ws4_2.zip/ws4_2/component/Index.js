export default {
    template:`
    <div>
    <div>
      <h1 class="text-center">메인페이지</h1>
    </div>
    <div>
      만든이 : SSAFY
    </div>
  </div>`
}