//사용할 컴포넌트들을 임포트
import Create from './component/Create.js'
import Delete from './component/Delete.js'
import List from './component/List.js'
import Read from './component/Read.js'
import Update from './component/Update.js'
import Index from './component/Index.js'

const router = new VueRouter({
    mode: 'history',
    routes: [
        {
            path: '/',
            name: 'index',
            component : Index
        },
        {
            path: '/list',
            name: 'list',
            component : List
        },
        {
            path: '/create',
            name: 'create',
            component : Create
        },
        {
            path: '/delete',
            name: 'delete',
            component : Delete
        },
        {
            path: '/read',
            name: 'read',
            component : Read
        },
        {
            path: '/update',
            name: 'update',
            component : Update
        },

    ]
})

// Vue 인스턴트 라우터 주입
const app = new Vue({
    el: '#app',
    router,
});
  