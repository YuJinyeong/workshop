export default {
  template: `
      <div>
      <div v-if="items.length">
        <table class="table table-bordered table-condensed">
          <colgroup>
            <col :style="{width: '10%'}" />
            <col :style="{width: '50%'}" />
            <col :style="{width: '15%'}" />
            <col :style="{width: '25%'}" />
          </colgroup>
          <tr>
            <th>번호</th>
            <th>제목</th>
            <th>작성자</th>
            <th>날짜</th>
          </tr>
          <tr v-for="(board, index) in items" :key="index + '_items'">
            <td>{{board.no}}</td>
            <td><router-link :to="'read?no=' + board.no">{{board.title}}</router-link></td>
            <td>{{board.writer}}</td>
            <td>{{getFormatDate(board.regtime)}}</td>
          </tr>
        </table>
      </div>
      <div v-else class="text-center">
        게시글이 없습니다.
      </div>
      <div class="text-right">
        <button class="btn btn-primary" @click="movePage">등록</button>
      </div>
      </div>
        
    `,
  data: function () {
    return {
      items : []
    }
  },
  created() {
    axios.get('http://192.168.21.37:8080/vue/api/board')
      .then(({ data }) => {
      this.items = data
    })
  },
  methods: {
    getFormatDate(regtime) {
      return moment(new Date(regtime)).format('YYYY.MM.DD');
    },
    movePage() {
      // location.href = 'create.html';
      this.$router.push('/create')
    },
  },
};
