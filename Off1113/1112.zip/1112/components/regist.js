export default {
  template: `
  <div id = "divPosition">
    <h4>사원추가</h4>
    <table id="table" border="1" bordercolor="lightgray">
      <tr>
        <td>이름</td>
        <td><input type="text" v-model="name" /></td>
      </tr>
      <tr>
        <td>이메일</td>
        <td><input type="email" v-model="email" /></td>
      </tr>
      <tr>
        <td>고용일</td>
        <td><input type="date" v-model="date" /></td>
      </tr>
      <tr>
        <td>관리자</td>
        <td>
          <select name="manager" v-model="manager">
            <option value="홍길동">홍길동</option>
            <option value="김싸피">김싸피</option>
          </select>
        </td>
      </tr>
      <tr>
        <td>직책</td>
        <td>
          <select name="position" v-model="position">
            <option value="사장">사장</option>
            <option value="부장">부장</option>
            <option value="과장">과장</option>
            <option value="사원">사원</option>
          </select>
        </td>
      </tr>
      <tr>
        <td>부서</td>
        <td>
          <select name="department" v-model="department">
            <option value="영업부">영업부</option>
            <option value="기획부">기획부</option>
            <option value="인사부">인사부</option>
          </select>
        </td>
      </tr>
      <tr>
        <td>월급</td>
        <td><input type="number" v-model="salary" />만원</td>
      </tr>
    </table>
    <button @click="regist()">사원추가</button>
    </div>`,
  data() {
    return {
      emps: getEmps(),
      name: '',
      email: '',
      date: '',
      manager: '',
      position: '',
      department: '',
      salary: '',
    };
  },
  methods: {
    regist: function () {
      this.emps.push({
        name: this.name,
        email: this.email,
        date: this.date,
        manager: this.manager,
        position: this.position,
        department: this.department,
        salary: this.salary,
      });
      localStorage.setItem('emps', JSON.stringify(this.emps));
      this.name = '';
      this.email = '';
      this.date = '';
      this.manager = '';
      this.position = '';
      this.department = '';
      this.salary = '';
      alert('등록되었습니다.');
    },
  },
};

function getEmps() {
  let emps = JSON.parse(localStorage.getItem('emps'));
  if (emps == null) {
    emps = [];
    localStorage.setItem('emps', JSON.stringify(emps));
  }
  return emps;
}
