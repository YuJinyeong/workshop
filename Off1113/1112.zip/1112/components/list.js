export default {
  template: `
  <div id="divPosition">
  <h4>사원목록</h4>
    <input type="text" v-model="keyword" placeholder="사원명 검색" />
    <table id="table" border="1" bordercolor="lightgray">
      <th>사원명</th>
      <th>부서</th>
      <th>직책</th>
      <th>연봉</th>
      <tr v-for="emp in emps" v-if="emp.name.includes(keyword)">
        <td>{{emp.name}}</td>
        <td>{{emp.department}}</td>
        <td>{{emp.position}}</td>
        <td>{{emp.salary}}</td>
      </tr>
    </table>
    </div>`,

  data() {
    return {
      emps: getEmps(),
      keyword: '',
    };
  },
};

function getEmps() {
  let emps = JSON.parse(localStorage.getItem('emps'));
  if (emps == null) {
    emps = [];
    localStorage.setItem('emps', JSON.stringify(emps));
  }
  return emps;
}
