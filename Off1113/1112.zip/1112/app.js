import List from './components/list.js';
import Regist from './components/regist.js';

const router = new VueRouter({
  routes: [
    {
      path: '/',
      name: 'list',
      component: List,
    },
    {
      path: '/regist',
      name: 'regist',
      component: Regist,
    },
  ],
});

const app = new Vue({
  el: '#app',
  router,
});
