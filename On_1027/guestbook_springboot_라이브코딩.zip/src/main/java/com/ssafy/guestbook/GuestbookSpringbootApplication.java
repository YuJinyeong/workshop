package com.ssafy.guestbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GuestbookSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(GuestbookSpringbootApplication.class, args);
	}

}
