package com.ssafy.firstboot.model;

import org.springframework.stereotype.Service;

@Service
public class HelloService {
	
	public String hello() {
		System.out.println("Hello");
		return "Hello";
	}
}
