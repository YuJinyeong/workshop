package com.ssafy.firstboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//이 녀석은 @Configuration
//이미 이 녁석이 속한 패키지를 scan하고 있다.
@SpringBootApplication
public class FirstBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstBootApplication.class, args);
	}
	
	// 필요하다면 명시적인 빈 선언 등이 가능하겠구나..!
	
	
}
