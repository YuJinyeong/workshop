package com.ssafy.firstboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.ssafy.firstboot.model.HelloService;

@Controller
public class HelloController {
	
	@Autowired
	HelloService service;
	
	@GetMapping("/hello")
	public String hello(Model model) {
		model.addAttribute("msg", service.hello());
		return "hello";
	}
	
	
	
}
