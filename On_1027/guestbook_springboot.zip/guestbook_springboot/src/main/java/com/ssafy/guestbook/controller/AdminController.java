package com.ssafy.guestbook.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ssafy.guestbook.model.MemberDto;
import com.ssafy.guestbook.model.service.UserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api("어드민 컨트롤러  API V1")
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private UserService userService;
	
	@ApiOperation(value = "회원목록", notes = "회원의 <big>전체 목록</big>을 반환해 줍니다.")
	@ApiResponses({
		@ApiResponse(code = 200, message = "회원목록 OK!!"),
		@ApiResponse(code = 404, message = "없어!!"),
		@ApiResponse(code = 500, message = "에러!!")
	})
	@GetMapping(value = "/user", headers = { "Content-type=application/json" })
	public List<MemberDto> userList() {
		return userService.userList();
	}
	
	@ApiOperation(value = "회원등록", notes = "회원의 정보를 받아 처리.")
	@PostMapping(value = "/user", headers = { "Content-type=application/json" })
	public List<MemberDto> userRegister(@RequestBody @ApiParam(value = "회원 한명의 정보.", required = true) MemberDto memberDto) {
		userService.userRegister(memberDto);
		return userService.userList();
	}
	
	@ApiOperation(value = "회원정보", notes = "회원한명에 대한 정보.")
	@GetMapping(value = "/user/{userid}", headers = { "Content-type=application/json" })
	public MemberDto userInfo(@PathVariable("userid") @ApiParam(value = "검색할 회원의 아이디") String userid) {
		return userService.userInfo(userid);
	}
	
	@ApiOperation(value = "회원정보수정", notes = "회원정보를 수정합니다.")
	@PutMapping(value = "/user", headers = { "Content-type=application/json" })
	public List<MemberDto> userModify(@RequestBody @ApiParam(value = "수정할 회원의 정보.", required = true) MemberDto memberDto) {
		userService.userModify(memberDto);
		return userService.userList();
	}
	
	@ApiOperation(value = "회원정보삭제", notes = "회원정보를 삭제합니다.")
	@DeleteMapping(value = "/user/{userid}", headers = { "Content-type=application/json" })
	public List<MemberDto> userDelete(@PathVariable("userid") @ApiParam(value = "삭제할 회원의 아이디") String userid) {
		userService.userDelete(userid);
		return userService.userList();
	}
	
}
