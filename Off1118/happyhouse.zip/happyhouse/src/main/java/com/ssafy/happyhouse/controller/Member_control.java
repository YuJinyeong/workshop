package com.ssafy.happyhouse.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.ssafy.happyhouse.model.dto.Member;
import com.ssafy.happyhouse.model.service.MemberService;

/**
 * Servlet implementation class Member_control
 */
@WebServlet("/Member_control")
public class Member_control extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Member_control() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			process(request, response);
		} catch (IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		try {
			process(request, response);
		} catch (IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void process(HttpServletRequest request, HttpServletResponse response)
			throws IOException, SQLException, ServletException {
		// TODO Auto-generated method stub
		String action = request.getParameter("action");
		System.out.println(action);

		if (action.equals("login_page")) { // move login page // get
			move_login_page(request, response);
		} else if (action.equals("login")) { // login check // post
			login(request, response);
		} else if (action.equals("register_page")) { // get
			move_register_page(request, response);
		} else if (action.equals("register")) { // post
			register(request, response);
		} else if (action.equals("logout")) { // logout
			logout(request, response);
		} else if (action.equals("Edit_info_page")) { // get
			move_edit_info_page(request, response);
		} else if (action.equals("basic_Info")) { // Member_Edit 처음 접속 했을 때, 회원정보 불러들이기
			basic_info(request, response); // get 
		} else if (action.equals("edit")) { // post
			edit(request, response);
		} else if (action.equals("delete")) { // get
			delete(request, response);
		}

	}

	private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		// TODO Auto-generated method stub
		

		// 2-1. Service 는 inser 를 위해서 DTO 사용 할듯
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("loginId");

		int result = MemberService.getInstance().delete(id);

		// 3. 삭제하기 유도
		if (result == 1) {
			request.setAttribute("msg", "삭제 성공 ! ");
			System.out.println("delete 성공 ! ");
			Cookie[] cookies = request.getCookies();

			// 1. cookie 삭제
			if (cookies != null) {
				for (Cookie cookie : cookies) {
					if (cookie.getName().equals("loginId")) {

						cookie.setMaxAge(0);
						cookie.setPath("/");
						response.addCookie(cookie);
						break;
					}
				}
			}
			// 2. session 종료
			session.invalidate();
			// index.jsp forward
			RequestDispatcher disp = request.getRequestDispatcher("/index.jsp");
			disp.forward(request, response);
		} else {
			System.out.println("삭제 되지 않았습니다. ");
			response.sendRedirect(request.getContextPath() + "/index.jsp");
		}
	}

	// 수정
	private void edit(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		// TODO Auto-generated method stub
		String id = request.getParameter("id");
		String pass = request.getParameter("pw");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		Member member = new Member(id, pass, name, email);

		// 2. member를 Service에 전달
		// 2-1. Service 는 inser 를 위해서 DTO 사용 할듯
		int result = MemberService.getInstance().edit(member);

		// 3. login 유도
		if (result == 1) {
			request.setAttribute("msg", "가입 성공, 로그인 후 사용해주세요.");
			System.out.println("회원 정보 수정 성공  !!");
			
			// session 값 변경된거로 바꿔주기 
			member = MemberService.getInstance().selectService(id);
			HttpSession session = request.getSession();
			session.setAttribute("loginId", id);
			session.setAttribute("loginpasswd", member.getPasswd());
			session.setAttribute("loginname", member.getName());
			session.setAttribute("loginemail", member.getEmail());
			
			// index.jsp forward
			RequestDispatcher disp = request.getRequestDispatcher("/index.jsp");
			disp.forward(request, response);
		} else {
			request.setAttribute("msg", "가입 실패 했습니다.");
			System.out.println(" 회원 정보 수정 실패 !!");
			RequestDispatcher disp = request.getRequestDispatcher("/Member_Edit.jsp");
			disp.forward(request, response);
		}
	}

	private void basic_info(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		Member member = null;
		JSONArray arr = new JSONArray();
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("loginId");

		try {
			member = MemberService.getInstance().selectService(id); // select 통해서 값 가져오기
			JSONObject obj = new JSONObject();
			obj.put("user_id", member.getId());
			obj.put("user_passwd", member.getPasswd());
			obj.put("user_name", member.getName());
			obj.put("user_email", member.getEmail());
			arr.add(obj);
		} catch (Exception e) {
			arr = new JSONArray();
			JSONObject obj = new JSONObject();
			obj.put("message_code", "-1");
			arr.add(obj);
			e.printStackTrace();
		} finally {
			out.print(arr.toJSONString());
			out.close();
		}

	}

	private void move_edit_info_page(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		response.sendRedirect(request.getContextPath() + "/Member_Edit.jsp");
	}

	private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		Cookie[] cookies = request.getCookies();

		// 1. cookie 삭제
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals("loginId")) {

					cookie.setMaxAge(0);
					cookie.setPath("/");
					response.addCookie(cookie);
					break;
				}
			}
		}
		// 2. session 종료
		HttpSession session = request.getSession();
		session.invalidate();

		// 3. index.jsp로 이동
		response.sendRedirect(request.getContextPath() + "/index.jsp");
	}

	private void register(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		// TODO Auto-generated method stub
		// 1. parameter 분석 --> Member
		String id = request.getParameter("id");
		String name = request.getParameter("pw");
		String pass = request.getParameter("name");
		String email = request.getParameter("email");
		Member member = new Member(id, name, pass, email);

		// 2. member를 Service에 전달
		// 2-1. Service 는 inser 를 위해서 DTO 사용 할듯
		int result = MemberService.getInstance().register(member);

		// 3. login 유도
		if (result == 1) {
			request.setAttribute("msg", "가입 성공, 로그인 후 사용해주세요.");
			System.out.println("회원 가입 성공 !!");
			// index.jsp forward
			RequestDispatcher disp = request.getRequestDispatcher("/login.jsp");
			disp.forward(request, response);
		} else {
			request.setAttribute("msg", "가입 실패 했습니다.");
			System.out.println(" 회원 가입 실패 !!");
			RequestDispatcher disp = request.getRequestDispatcher("/register.jsp");
			disp.forward(request, response);
		}

	}

	private void move_register_page(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		response.sendRedirect(request.getContextPath() + "/register.jsp");
	}

	private void login(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		// TODO Auto-generated method stub
		Member member = null;
		String id = request.getParameter("id");
		String pass = request.getParameter("passwd");
		System.out.println("내가 입력한 pw : " + pass );
		boolean result = MemberService.getInstance().login(id, pass);
		// 성공 -> main.jsp, 세션 등록, 쿠키 저장
		if (result) {
			Cookie cookie = new Cookie("loginId", id);
			cookie.setMaxAge(60 * 1);
			cookie.setPath("/");
			response.addCookie(cookie);

			// 세션에 태워서 보내기
			member = MemberService.getInstance().selectService(id);
			HttpSession session = request.getSession();
			session.setAttribute("loginId", id);
			session.setAttribute("loginpasswd", member.getPasswd());
			session.setAttribute("loginname", member.getName());
			session.setAttribute("loginemail", member.getEmail());
			response.sendRedirect(request.getContextPath() + "/index.jsp");
		}
		// 실패 --> index.jsp
		else {
			request.setAttribute("msg", "아이디 / 비밀번호를 확인하세요.");
			System.out.println("login 실패 ");
			RequestDispatcher disp = request.getRequestDispatcher("/login.jsp");
			disp.forward(request, response);
		}
	}

	private void move_login_page(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		response.sendRedirect(request.getContextPath() + "/login.jsp");
	}

}
