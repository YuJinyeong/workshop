package com.ssafy.happyhouse.model.service;

import java.sql.Connection;
import java.sql.SQLException;

import com.ssafy.happyhouse.model.dto.Member;
import com.ssafy.happyhouse.model.repo.MemberRepoImpl;
import com.ssafy.util.DBUtil;

public class MemberService {
	private MemberRepoImpl dao = MemberRepoImpl.getDao();

	private static MemberService service;

	// 싱글턴 디자인 패턴 적용하기
	private MemberService() {

	}

	public static MemberService getInstance() {
		if (service == null) {
			service = new MemberService();
		}
		return service;
	}
	// login 완료
	public boolean login(String id, String pass) throws SQLException {
		// 원ㄹㅐDb거쳐서 연동

		// connection : auto closeable , AutoClose 를 상속받고 있어요.
		try (Connection con = (Connection) DBUtil.getConnection()) {

			System.out.println(con);
			Member member = dao.select(con, id);
			
			if (member != null && member.getPasswd().equals(pass)) {
				return true;
			} else {
				return false;
			}
		}

	}
	
	
	// 서비스 : Transaction 처리의 책임, Connection 생성 후 TX 관리
	public Member selectService(String id) throws SQLException {
		//int a = 1/0;
		// 원ㄹㅐDb거쳐서 연동
		Member member = null;
		// connection : auto closeable , AutoClose 를 상속받고 있어요.
		Connection con = (Connection) DBUtil.getConnection();
		member = dao.select(con, id);
		
		return member;
	}

	
	// [ 우리의 가입 업무 ] 
	// 1. 회원가입을 한다. == 회원 DB에 저장한다.
	// 2. 가입된 회원을 조회해서 console에 출력한다.
	
	public int register(Member member) throws SQLException {
		System.out.println("Membser Service 등록 함수  !! ");
		int result = -1;
		// 원ㄹ ㅐDb거쳐서 연동
		Connection con = null;
		try{
			con = DBUtil.getConnection();
			// 1. autocommit 중지 
			con.setAutoCommit(false);
			
			
			// dao 호출
			result = dao.insert(con,member);
			// 사용자로 로그인해보자.
			//Product selected = dao.select(con, product.getNumber()); // --> ZeroDivision 나와서 에러 떠야함 [ 트랜 잭션 처리안하면 생기는 불상사 ] - 에러인데 DB에 저장되면 안됨
			//System.out.println(selected);
			
			// 2. 여기까지 실행 되었다는 것은? => 성공을 의미한다.
			con.commit();
		} catch( Exception e ) {
			result = -1;
			// 3. 에러 발생 시 롤백
			con.rollback();
		} finally {
			
			// 4. 모드 되돌리기 -> select 에서는 autocommit 모드가 훨씬 빠르다.
			con.setAutoCommit(true);
			DBUtil.close(con);
		}

		return result;
	}
	public int edit(Member member) throws SQLException {
		System.out.println("EDIT Service 화면 ");
		int result = -1;
		Connection con = null;
		
		try{
			con = DBUtil.getConnection();
			// 1. autocommit 중지 
			con.setAutoCommit(false);
			
			
			// dao 호출
			result = dao.update(con,member);
			
			// 사용자로 로그인해보자.
			//Product selected = dao.select(con, product.getNumber()); // --> ZeroDivision 나와서 에러 떠야함 [ 트랜 잭션 처리안하면 생기는 불상사 ] - 에러인데 DB에 저장되면 안됨
			//System.out.println(selected);
			
			// 2. 여기까지 실행 되었다는 것은? => 성공을 의미한다.
			con.commit();
		} catch( Exception e ) {
			result = -1;
			// 3. 에러 발생 시 롤백
			con.rollback();
		} finally {
			
			// 4. 모드 되돌리기 -> select 에서는 autocommit 모드가 훨씬 빠르다.
			con.setAutoCommit(true);
			DBUtil.close(con);
		}

		
		return result;
		
		
	}
	
	public int delete(String id) throws SQLException {
		int result = -1;
		Connection con = null;
		
		try{
			con = DBUtil.getConnection();
			// 1. autocommit 중지 
			con.setAutoCommit(false);
			
			
			// dao 호출
			result = dao.delete(con,id);
			
			// 사용자로 로그인해보자.
			//Product selected = dao.select(con, product.getNumber()); // --> ZeroDivision 나와서 에러 떠야함 [ 트랜 잭션 처리안하면 생기는 불상사 ] - 에러인데 DB에 저장되면 안됨
			//System.out.println(selected);
			
			// 2. 여기까지 실행 되었다는 것은? => 성공을 의미한다.
			con.commit();
		} catch( Exception e ) {
			result = -1;
			// 3. 에러 발생 시 롤백
			con.rollback();
		} finally {
			
			// 4. 모드 되돌리기 -> select 에서는 autocommit 모드가 훨씬 빠르다.
			con.setAutoCommit(true);
			DBUtil.close(con);
		}

		
		return result;
	}
}
