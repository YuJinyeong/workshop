package com.ssafy.webex.model.repo;

import java.util.List;
import java.util.Map;

import com.ssafy.webex.model.dto.HouseInfoDto;
import com.ssafy.webex.model.dto.SidoGugunCodeDto;

public interface HouseMapRepository {
	//List<SidoCodeDto> getSido() throws Exception;
	Map<String, String> getSido() throws Exception;
	List<SidoGugunCodeDto> getGugunInSido(String sido) throws Exception;
	List<HouseInfoDto> getDongInGugun(String gugun) throws Exception;
	List<HouseInfoDto> getAptInDong(String dong) throws Exception;
}
