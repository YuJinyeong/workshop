package com.ssafy.webex.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.ssafy.webex.model.dto.HouseInfoDto;
import com.ssafy.webex.model.dto.SidoCodeDto;
import com.ssafy.webex.model.dto.SidoGugunCodeDto;
import com.ssafy.webex.model.service.HouseMapService;

@Controller
public class HouseMapController{
	
	@Autowired
	private HouseMapService houseMapService;
	
	@GetMapping("/map")
	public void mapping(Model model, HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("맵걸림");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("UTF-8");
		String act = request.getParameter("act");
		if ("sido".equals(act)) {
			PrintWriter out = response.getWriter();
			List<SidoCodeDto> list = null;
			JSONArray arr = new JSONArray();
			try {
				list = houseMapService.getSido();
				for (SidoCodeDto dto : list) {
					System.out.println(dto);
					JSONObject obj = new JSONObject();
					obj.put("sido_code", dto.getSidoCode()); // {'sido_code' : '11'}
					obj.put("sido_name", dto.getSidoName()); // {'sido_code' : '11', 'sido_name' : '서울'}
					arr.add(obj);
				}
			} catch (Exception e) {
				arr = new JSONArray();
				JSONObject obj = new JSONObject();
				obj.put("message_code", "-1");
				arr.add(obj);
				e.printStackTrace();
			} finally {
				out.print(arr.toJSONString());
				out.close();
			}
		} // sido
		else if ("gugun".equals(act)) {
			String sido = request.getParameter("sido");
			PrintWriter out = response.getWriter();
			List<SidoGugunCodeDto> list = null;
			JSONArray arr = new JSONArray();
			try {
				list = houseMapService.getGugunInSido(sido);
				for (SidoGugunCodeDto dto : list) {
					JSONObject obj = new JSONObject();
					obj.put("gugun_code", dto.getGugunCode());
					obj.put("gugun_name", dto.getGugunName());
					arr.add(obj);
				}
			} catch (Exception e) {
				arr = new JSONArray();
				JSONObject obj = new JSONObject();
				obj.put("message_code", "-1");
				arr.add(obj);
				e.printStackTrace();
			} finally {
				out.print(arr.toJSONString());
				out.close();
			}
		} // gugun
		else if ("dong".equals(act)) {
			String gugun = request.getParameter("gugun");
			PrintWriter out = response.getWriter();
			List<HouseInfoDto> list = null;
			JSONArray arr = new JSONArray();
			try {
				list = houseMapService.getDongInGugun(gugun);
				for (HouseInfoDto dto : list) {
					JSONObject obj = new JSONObject();
					obj.put("code", dto.getCode());
					obj.put("dong", dto.getDong());
					arr.add(obj);
				}
			} catch (Exception e) {
				arr = new JSONArray();
				JSONObject obj = new JSONObject();
				obj.put("message_code", "-1");
				arr.add(obj);
				e.printStackTrace();
			} finally {
				out.print(arr.toJSONString());
				out.close();
			}
		} // dong
		else if ("apt".equals(act)) {
			String dong = request.getParameter("dong");
			PrintWriter out = response.getWriter();
			List<HouseInfoDto> list = null;
			JSONArray arr = new JSONArray();
			try {
				list = houseMapService.getAptInDong(dong);
				for (HouseInfoDto dto : list) {
					JSONObject obj = new JSONObject();
					obj.put("no", dto.getNo());
					obj.put("dong", dto.getDong());
					obj.put("aptName", dto.getAptName());
					obj.put("code", dto.getCode());
					obj.put("jibun", dto.getJibun());
					arr.add(obj);
				}
			} catch (Exception e) {
				arr = new JSONArray();
				JSONObject obj = new JSONObject();
				obj.put("message_code", "-1");
				arr.add(obj);
				e.printStackTrace();
			} finally {
				out.print(arr.toJSONString());
				out.close();
			}
		}
	}
}