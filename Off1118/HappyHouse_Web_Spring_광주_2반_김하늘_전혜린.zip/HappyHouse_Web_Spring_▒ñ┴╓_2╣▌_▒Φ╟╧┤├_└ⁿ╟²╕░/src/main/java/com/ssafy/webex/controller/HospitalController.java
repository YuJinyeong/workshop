package com.ssafy.webex.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.webex.model.dto.CoronaHospitalDto;
import com.ssafy.webex.model.service.CoronaHospitalService;
import com.ssafy.webex.util.PageNavigation;

@Controller
@RequestMapping("/hospital")
public class HospitalController{
	
	@Autowired
	private CoronaHospitalService coronaHospitalService;
	
	@RequestMapping(value = "/searchAll", method = RequestMethod.GET)
	public String goSearchAll(Model model, @RequestParam Map<String, String> map) {
		String spp = map.get("spp");
		map.put("spp", spp != null ? spp : "10");//sizePerPage
		try {			
			List<CoronaHospitalDto> list = coronaHospitalService.searchAll(map);
			PageNavigation pageNavigation = coronaHospitalService.makePageNavigation(map);
			
			for(CoronaHospitalDto c: list) {
				System.out.println(c);
			}
			model.addAttribute("hospitals", list);
			model.addAttribute("navigation", pageNavigation);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "hospital/searchList";
	}
}