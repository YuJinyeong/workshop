package com.ssafy.webex.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.webex.model.dto.MemberDto;
import com.ssafy.webex.model.service.MemberService;

/**
 * Servlet implementation class UserController
 */
@Controller
@RequestMapping("/user")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Autowired
	private MemberService memberService;

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String goHome() {
		return "index";
	}
	
	@RequestMapping(value = "/mvlogin", method = RequestMethod.GET)
	public String goLogin() {
		return "user/login";
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String goLogout(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.removeAttribute("userinfo");
		return "index";
	}
	
	@RequestMapping(value = "/mvjoin", method = RequestMethod.GET)
	public String goJoin() {
		return "user/join";
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(@RequestParam Map<String, String> map, HttpServletRequest request, HttpServletResponse response){
		System.out.println("login시작");
		String userid = map.get("userid");
		String userpwd = map.get("userpwd");
		try {
			MemberDto memberDto = memberService.login(map); // null인지 null이 아닌지에 따라서 로그인의 여부가 결정
			if(memberDto != null) { // 로그인 성공
				HttpSession session = request.getSession();
				session.setAttribute("userinfo", memberDto);
				String idsv = request.getParameter("idsave");
				if("saveok".equals(idsv)) { // 아이디 저장 체크
					Cookie cookie = new Cookie("ssafy_id", userid);
					System.out.println(userid);
					cookie.setPath(request.getContextPath()); // 어느 경로에서 사용할지 설정
					cookie.setMaxAge(60*60*24);
					response.addCookie(cookie);
					System.out.println("쿠키 만들기 성공!");
				}else { // 체크 해제
					Cookie[] cookies = request.getCookies();
					if(cookies != null){
						for(Cookie cookie : cookies){
							if(cookie.getName().equals("ssafy_id")){
								cookie.setPath(request.getContextPath());
								cookie.setMaxAge(0); // 쿠기는 지우는게 없기 때문에 setMaxAge(0) 사용
								response.addCookie(cookie);
								break;
							}
						}
					}
				}
			}else { // 실패
				request.setAttribute("msg", "아이디 또는 비밀번호를 확인해 주세요.");
				System.out.println("로그인실패");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			request.setAttribute("msg", "로그인 중 문제가 발생했습니다.");
		}
		System.out.println("login 정상종료");
		return "index";
	}

	
	@PostMapping("/join")
	public String join(HttpServletRequest request){
		String uid = request.getParameter("userid");
		String upw = request.getParameter("userpwd");
		String uname = request.getParameter("username");
		String tel1 = request.getParameter("tel1");
		String tel2 = request.getParameter("tel2");
		String tel3 = request.getParameter("tel3");
		String address = request.getParameter("address");
		MemberDto memberdto = new MemberDto();
		memberdto.setId(uid);
		memberdto.setPassword(upw);
		memberdto.setName(uname);
		memberdto.setPhone(tel1+"-"+tel2+"-"+tel3);
		memberdto.setAddr(address);
		System.out.println(memberdto);
		try {
			memberService.join(memberdto);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("에러발생");
		}
		return "user/joinsuccess";
	}
	
	@GetMapping("/info")
	public String goInfo() {
		return "user/info";
	}

	@GetMapping("/mvmodify")
	public String goModify(Model model, HttpServletRequest request) {
		String userid = request.getParameter("userid");
		MemberDto memberDto;
		try {
			memberDto = memberService.getInfo(userid);
			model.addAttribute("info", memberDto);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("에러발생");
		}
		return "user/modify";
	}
	
	@PostMapping("/modify")
	public String modifyInfo(HttpServletRequest request) {
		MemberDto memberDto = new MemberDto();
		memberDto.setId(request.getParameter("userid"));
		memberDto.setPassword(request.getParameter("userpwd"));
		memberDto.setName(request.getParameter("username"));
		memberDto.setAddr(request.getParameter("address"));
		memberDto.setPhone(request.getParameter("tel1")+"-"+request.getParameter("tel2")+"-"+request.getParameter("tel3"));
		try {
			memberService.modifyInfo(memberDto);
			HttpSession session = request.getSession();
			session.setAttribute("userinfo", memberDto);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("에러발생");
		}
		return "user/info";
	}
	
	@GetMapping("/delete")
	public String deleteInfo(HttpServletRequest request) {
		String userid = request.getParameter("userid");
		try {
			memberService.delete(userid);
			HttpSession session = request.getSession();
			session.removeAttribute("userinfo"); // 세션 안에는 여러개 넣을 수 있다. 장바구니에 이것이 적절
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("에러발생");
		}
		return "user/deletesuccess";
	}

//	private void findpwd(HttpServletRequest request, HttpServletResponse response) throws IOException {
//		String rootpath = request.getContextPath();
//		String path = "/index.jsp";
//		
//		String userid = request.getParameter("userid");
//		String username = request.getParameter("username");
//		String tel1 = request.getParameter("tel1");
//		String tel2 = request.getParameter("tel2");
//		String tel3 = request.getParameter("tel3");
//		String phone = tel1+"-"+tel2+"-"+tel3; 
//		
//		MemberDto memberDto;
//		
//		try {
//			memberDto = memberService.getPwd(userid, username, phone);
//			System.out.println("find>>>>>>>>>"+memberDto.getId());
//			System.out.println("find>>>>>>>>>"+memberDto.getName());
//			System.out.println("find>>>>>>>>>"+memberDto.getPassword());
//			path = "/user/findsuccess.jsp";
//			HttpSession session = request.getSession();
//			session.setAttribute("findinfo", memberDto);
//			redirect(response, path, rootpath);
//		} catch (Exception e) {
//			e.printStackTrace();
//			request.setAttribute("msg", "비밀번호 찾기 중 문제가 발생했습니다.");
//			path = "/error/error.jsp";
//			redirect(response, path, rootpath);
//		}
//		
//	}
}