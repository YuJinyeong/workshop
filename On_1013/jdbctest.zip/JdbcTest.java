package com.ssafy.jdbc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * JDBC 작업 순서
 * 1. Driver Loading
 * 2. DB 연결 (Connection 생성)
 * 3. SQL 실행 준비
 *   3-1. SQL 작성.
 *   3-2. Statement 생성 (Statement, PreparedStatement)
 * 4. SQL 실행
 *   4-1. I, U, D
 *      int x = stmt.execteUpdate(sql);
 *   	int x = pstmt.executeUpdate();
 *   4-2. S
 *      ResultSet rs = pstmt.executeQuery();
 *      rs.next() [단독, if, while]
 *      값얻기 : rs.getString()
 *            rs.getInt() 등등등....
 * 5. DB 연결 종료 : 연결 역순으로 종료, finally
 * 	if(rs != null)
 *    	rs.close()
 *  if(pstmt != null)
 *  	pstmt.close();
 *  if(conn != null)
 *  	conn.close();
 */
public class JdbcTest {
	
	private final String driver = "com.mysql.cj.jdbc.Driver";
	private final String url = "jdbc:mysql://127.0.0.1:3306/ssafydb?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
	private final String dbid = "ssafy";
	private final String dbpwd = "ssafy";
	
	public JdbcTest() {
		
	}
	
	public static void main(String[] args) throws IOException {
		JdbcTest test = new JdbcTest();
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		JdbcDto jdbcDto = new JdbcDto();
		System.out.print("아이디 : ");
		jdbcDto.setId(in.readLine());
		System.out.print("비밀번호 : ");
		jdbcDto.setPwd(in.readLine());
		System.out.print("이름 : ");
		jdbcDto.setName(in.readLine());
		
		int cnt = ;
		
		if()
			System.out.println("등록 성공!!!");
		
		System.out.print("검색할 아이디 : ");
		String sid = in.readLine();
		
		if() {
			System.out.println(sid + "회원 정보!!!");
			System.out.println("이름 : ");
			System.out.println("비번 : ");
			System.out.println("가입일 : ");
		} else {
			System.out.println(sid + " 회원은 없습니다.");
		}
		
		System.out.print("수정 할 회원 아이디 : ");
		String mid = in.readLine();
		System.out.print("수정할 비밀 번호 : ");
		String mpwd = in.readLine();
		
		cnt = ;
		System.out.println(cnt + "개 정보 수정!!!");
		
		System.out.print("탈퇴 할 회원 아이디 : ");
		String did = in.readLine();
		
		cnt = ;
		System.out.println(cnt + "명 탈퇴!!!");
		
		System.out.println("--- 모든 회원 정보 ---");
		System.out.println("이름\t아이디\t비밀번호\t가입일");
		System.out.println("----------------------------------");
		for() {
			
		}
	}
}
